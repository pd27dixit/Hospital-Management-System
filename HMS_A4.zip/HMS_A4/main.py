from flask import Flask, render_template, request, redirect,url_for,flash,session
from flask_mysqldb import MySQL
import numpy as np
from datetime import datetime, timedelta
import math

now = datetime.now().strftime('%H:%M')
import MySQLdb.cursors

app = Flask(__name__)
app.secret_key = 'the random string'

app.config['MYSQL_HOST'] = '10.5.18.68'
app.config['MYSQL_USER'] = '20CS10026'
app.config['MYSQL_PASSWORD'] = '20CS10026'
app.config['MYSQL_DB'] = '20CS10026'

mysql = MySQL(app)

@app.route('/')
@app.route('/login', methods =['GET', 'POST'])
def login():
    if "user" in session:
        if session["usertype"]=="admin":
            return redirect("/index")
        else:
            return redirect("/health_info")
    msg=""
    if request.method == 'GET':
        if request.form.get("userid") is None:
            return render_template('login.html')
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute("SELECT * FROM login")
    data = cursor.fetchall()
    
    for item in data:
        assert isinstance(item, object)

    userfound = False
    for id in data:
        if request.form.get("userid") == id['userid']:
            userfound = True

    if not userfound:
        

        return render_template('login.html')
    

    for item in data:
        userid = item['userid']
        password = item['password']
        usertype=item['usertype']
        session["usertype"] = usertype
        session["userid"] = userid
        session["user"]=usertype
        
        
        if request.method == 'POST':
            if userid == request.form.get("userid"):
                if password != request.form.get("password"):
                    
                    return render_template('login.html')
                    
                else:
                    if  usertype == 'admin':
                        return redirect(url_for('index'))
                    elif usertype == 'patient':
                        return redirect("/health_info")
                    elif usertype == 'frontdesk':
                        return redirect("/frontdesk")
                    elif usertype == 'doctor':
                        session["userid"] = userid
                        return redirect("/doctordash")
                    elif usertype == 'data_entry':
                        session["userid"]=userid
                        return redirect("/data_entry")
                    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop("userid",None)
    session.pop("user",None)
    return redirect("/login")

@app.route("/index")
def index():
    if "user" in session:
        if session["usertype"] == "admin":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute("SELECT COUNT(*) FROM patient")
            count = cursor.fetchall()

            cursor.execute("SELECT COUNT(*) FROM doctor")
            count_doc = cursor.fetchall()
            cursor.execute("SELECT * FROM doctor")
            doctor = cursor.fetchall()
            cursor.execute("SELECT COUNT(*) FROM login WHERE usertype='%s'" %("frontdesk"))
            count_fd = cursor.fetchall()
            cursor.execute("SELECT COUNT(*) FROM login WHERE usertype='%s'" %("data_entry"))
            count_de = cursor.fetchall()
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            
            cursor.execute("SELECT * FROM patient")
            patient = cursor.fetchall()

            cursor.execute("select * from appointment , doctor, patient where  appointment.doctorid=doctor.doctorid and appointment.patientid=patient.patientid and NOT appointment.status='%s' order by appointment.appointmentdate desc" %("PENDING"))
            appointment = cursor.fetchall()
                
            return render_template('index.html',count = count ,count_doc = count_doc ,count_fd=count_fd,count_de=count_de,doctor =doctor,patient = patient ,appointment=appointment)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/frontdesk")
def frontdesk():
    if "user" in session:
        if session["usertype"] == "frontdesk":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute("SELECT COUNT(*) FROM patient")
            count = cursor.fetchall()
            cursor.execute("SELECT COUNT(*) FROM login WHERE usertype='%s'" %("frontdesk"))
            count_fd = cursor.fetchall()
            cursor.execute("SELECT COUNT(*) FROM login WHERE usertype='%s'" %("data_entry"))
            count_de = cursor.fetchall()


            cursor.execute("SELECT COUNT(*) FROM doctor")
            count_doc = cursor.fetchall()
            cursor.execute("SELECT * FROM doctor")
            doctor = cursor.fetchall()
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            
            cursor.execute("SELECT * FROM patient")
            patient = cursor.fetchall()

            cursor.execute("select * from appointment , doctor, patient where  appointment.doctorid=doctor.doctorid and appointment.patientid=patient.patientid and appointment.status='%s'" %("APPROVED"))
            appointment = cursor.fetchall()
                
            return render_template('index2.html',count = count ,count_doc = count_doc ,count_fd=count_fd,count_de=count_de,doctor =doctor,patient = patient ,appointment=appointment)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")


@app.route("/doctors")
def doctors():
    if "user" in session:
        if session["usertype"] == "admin":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            
            cursor.execute("SELECT * FROM doctor WHERE status='ACTIVE'")
            doctor = cursor.fetchall()
            cursor.execute("SELECT * FROM doctor WHERE status='INACTIVE'")
            inactivedoctor = cursor.fetchall()
            
            return render_template('doctors.html',doctor=doctor,inactivedoctor=inactivedoctor)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/add_doctor")
def add_doctor():
    if "user" in session:
        if session["usertype"] == "admin":
            return render_template('add-doctor.html')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")
    
@app.route("/frontdesks")
def frontdesks():
    if "user" in session:
        if session["usertype"] == "admin":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            
            cursor.execute("SELECT * FROM login WHERE usertype='frontdesk'")
            login = cursor.fetchall()
            
            return render_template('frontdesks.html',login=login)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")
    
@app.route("/admin_frontdesk")
def admin_frontdesk():
    if "user" in session:
        if session["usertype"] == "admin":
            return render_template('add-frontdesk.html')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")
    
@app.route("/addfrontdesk", methods = ['GET', 'POST'])
def addfrontdesk():
    if "user" in session:
        if session["usertype"] == "admin":
            if request.method == 'POST':
                
                cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                userid=request.form.get("userid")
                #email=request.form.get("email")
                password=request.form.get("password")
                cnfpassword=request.form.get("cnfpassword")
                
                
                #password verification
                if not password==cnfpassword:
                    pmsg="Passwords did not match. Try again."
                    flash(pmsg)
                    return render_template('add-frontdesk.html')

               
                
                #cursor.execute("INSERT INTO login (doctorid, doctorname,mobileno,departmentname, status,education,experience,consultancy_charge,gender) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" %(doctorid, name,phone,departmentname,status,education,experience,consultancycharge,gender))
                #mysql.connection.commit()
                cursor.execute("INSERT INTO login VALUES ('%s', '%s', 'frontdesk')" %(userid, password))
                mysql.connection.commit()

                smsg="Front Desk Operator added successfully.\nUserID is "+userid+"."
                flash(smsg, 'success')
                return redirect("/admin_frontdesk")
        else :
            return redirect("/logout")
    else :
        return redirect("/login")
    
@app.route("/deletefrontdesk/<userid>")
def deletefrontdesk(userid):
    if "user" in session:
        if session["usertype"] == "admin":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute("DELETE from login where userid='%s'" %(userid))
            mysql.connection.commit()
            return redirect('/frontdesks')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")


@app.route("/adddoctors", methods = ['GET', 'POST'])
def adddoctors():
    if "user" in session:
        if session["usertype"] == "admin":
            if request.method == 'POST':
                
                cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                name=request.form.get("name")
                email=request.form.get("email")
                password=request.form.get("password")
                cnfpassword=request.form.get("cnfpassword")
                departmentname=request.form.get("departmentname")
                status=request.form.get("status")
                gender=request.form.get("gender")
                education=request.form.get("education")
                experience=request.form.get("experience")
                consultancycharge=request.form.get("consultancycharge")
                phone=request.form.get("phone")
                
                #password verification
                if not password==cnfpassword:
                    pmsg="Passwords did not match. Try again."
                    flash(pmsg)
                    return render_template('add-doctor.html')

                cursor.execute("SELECT COUNT(*) FROM doctor")
                doc_count = cursor.fetchall()
                print("Patient count is "+str(doc_count[0]['COUNT(*)']))
                doctorid = ""
                doctorid = "D"+str(1+(doc_count[0]['COUNT(*)']))
                
                cursor.execute("INSERT INTO doctor (doctorid, doctorname,mobileno,departmentname, status,education,experience,consultancy_charge,gender) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" %(doctorid, name,phone,departmentname,status,education,experience,consultancycharge,gender))
                mysql.connection.commit()
                cursor.execute("INSERT INTO login VALUES ('%s', '%s', 'doctor')" %(doctorid, password))
                mysql.connection.commit()

                smsg="Doctor added successfully.\nDoctor ID is "+doctorid+"."
                flash(smsg, 'success')
                return redirect("/add_doctor")
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/roomoccupancy")
def roomoccupancy():
    if "user" in session:
        if session["usertype"] == "frontdesk":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute("select * from appointment , doctor, patient where  appointment.doctorid=doctor.doctorid and appointment.patientid=patient.patientid and appointment.status='%s' and patient.patientid not in (select stay.patientid from stay)" %("OBSERVATION"))
            obs=cursor.fetchall()
            cursor.execute("SELECT * FROM stay NATURAL JOIN patient NATURAL JOIN appointment")
            stay=cursor.fetchall()
            return render_template('occupancy.html', obs=obs, stay=stay)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/allotroom/<int:appointmentid>/<patientid>")
def allotroom(appointmentid, patientid):
    if "user" in session:
        if session["usertype"] == "frontdesk":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute("SELECT * FROM room WHERE status='%s'" %("AVAILABLE"))
            roomno = cursor.fetchone()

            if roomno is None:
                msg="Room occupation is full!"
                flash(msg)
                return redirect("/roomoccupancy")

            cursor.execute("INSERT INTO stay(roomno, patientid, appointmentid) VALUES ('%d', '%s', '%d')" %(roomno['roomno'], patientid, appointmentid))
            cursor.execute("UPDATE room SET status = '%s' WHERE roomno='%d'" %("UNAVAILABLE", (roomno['roomno'])))

            mysql.connection.commit()

            msg="Room "+str(roomno['roomno'])+" is alloted successfully"
            flash(msg)
            return redirect("/roomoccupancy")
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/discharge/<int:stayid>")
def discharge(stayid):
    if "user" in session:
        if session["usertype"] == "frontdesk":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute("SELECT * FROM stay WHERE stayid='%d'" %(stayid))
            roomno = cursor.fetchone()
            cursor.execute("UPDATE room SET status = '%s' WHERE roomno='%d'" %("AVAILABLE", (roomno['roomno'])))
            cursor.execute("DELETE FROM stay WHERE stayid='%d'" %(stayid))
            mysql.connection.commit()
            msg="Patient discharged successfully"
            flash(msg)
            return redirect("/roomoccupancy")
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/adddoctor", methods = ['GET', 'POST'])
def adddoctor():
    if "user" in session:
        if session["usertype"] == "admin":
            if request.method == 'POST':
                cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                name=request.form.get("name")
                phone=request.form.get("phone")
                gender=request.form.get("gender")
                education=request.form.get("education")
                department=request.form.get("department")
                experience=request.form.get("exp")
                consultancy_charge=request.form.get("charge")
                status=request.form.get("status")
                start_time=request.form.get("starttime")
                end_time=request.form.get("endtime")
                cursor.execute("INSERT INTO doctor (doctorname, mobileno,departmentname,status,education,experience,consultancy_charge,gender,start_time,end_time) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s')" %(name,phone,department,status,education,experience,consultancy_charge,gender,start_time,end_time))
                mysql.connection.commit()
                return redirect("/doctors")
            else :
                return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/deletedoctor/<doctorid>")
def deletedoctor(doctorid):
    if "user" in session:
        if session["usertype"] == "admin":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute("UPDATE doctor SET status='INACTIVE' where doctorid='%s'" %(doctorid))
            mysql.connection.commit()
            return redirect('/doctors')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")
    
@app.route("/makeactivedoctor/<doctorid>")
def makeactivedoctor(doctorid):
    if "user" in session:
        if session["usertype"] == "admin":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute("UPDATE doctor SET status='ACTIVE' where doctorid='%s'" %(doctorid))
            mysql.connection.commit()
            return redirect('/doctors')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/appointments")
def appointments():
    if "user" in session:
        if session["usertype"] == "frontdesk":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

            cursor.execute("select * from appointment , doctor, patient where  appointment.doctorid=doctor.doctorid and appointment.patientid=patient.patientid")
            app = cursor.fetchall()
            return render_template('appointments.html', app=app)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/patients")
def patients():
    if "user" in session:
        if session["usertype"] == "frontdesk":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

            cursor.execute("SELECT * FROM patient")
            patient = cursor.fetchall()
            return render_template('frontdesk.html', patient=patient)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/approveappointment/<int:appointmentid>")
def approveappointment(appointmentid):
    if "user" in session:
        if session["usertype"] == "frontdesk":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

            cursor.execute("UPDATE appointment SET status='%s' WHERE appointmentid='%s'" %("APPROVED",(appointmentid)))
            mysql.connection.commit()
                
            return redirect('/appointments')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/disapproveappointment/<int:appointmentid>")
def disapproveappointment(appointmentid):
    if "user" in session:
        if session["usertype"] == "frontdesk":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

            cursor.execute("DELETE FROM appointment WHERE appointmentid='%s'" %(appointmentid))
            mysql.connection.commit()
                
            return redirect('/appointments')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/takeupappointment/<int:appointmentid>")
def takeupappointment(appointmentid):
    if "user" in session:
        if session["usertype"] == "frontdesk":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

            cursor.execute("UPDATE appointment SET status='%s' WHERE appointmentid='%s'" %("ONGOING",(appointmentid)))
            mysql.connection.commit()
                
            return redirect('/frontdesk')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/add_patient")
def add_patient():
    if "user" in session:
        if session["usertype"] == "frontdesk":
            return render_template('add-patient.html')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/addpatients", methods = ['GET', 'POST'])
def addpatients():
    if "user" in session:
        if session["usertype"] == "frontdesk":
            if request.method == 'POST':
                
                cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                name=request.form.get("name")
                email=request.form.get("email")
                password=request.form.get("password")
                cnfpassword=request.form.get("cnfpassword")
                age=request.form.get("age")
                blood_group=request.form.get("blood-group")
                gender=request.form.get("gender")
                address=request.form.get("address")
                city=request.form.get("city")
                pincode=request.form.get("pincode")
                phone=request.form.get("phone")
                illness=request.form.get("illness")

                #password verification
                if not password==cnfpassword:
                    pmsg="Passwords did not match. Try again."
                    flash(pmsg)
                    return render_template('add-patient.html')

                cursor.execute("SELECT COUNT(*) FROM patient")
                patient_count = cursor.fetchall()
                print("Patient count is "+str(patient_count[0]['COUNT(*)']))
                patientid = ""
                patientid = "P"+str(1+(patient_count[0]['COUNT(*)']))
                
                cursor.execute("INSERT INTO patient (patientid, patientname,email,address, mobileno,city,pincode,bloodgroup,gender,age,illness) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" %(patientid, name, email,address,phone,city,pincode,blood_group,gender,age,illness))
                mysql.connection.commit()
                cursor.execute("INSERT INTO login VALUES ('%s', '%s', 'patient')" %(patientid, password))
                mysql.connection.commit()

                smsg="Patient added successfully.\nPatient ID is "+patientid+"."
                flash(smsg, 'success')
                return render_template("frontdesk.html")
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/deletepatient/<patientid>")
def deletepatient(patientid):
    if "user" in session:
        if session["usertype"] == "frontdesk":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute("DELETE from patient where patientid='%s'" %(patientid))
            mysql.connection.commit()
            return redirect('/frontdesk')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/schedule")
def schedule():
    if "user" in session:
        if session["usertype"] == "admin":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            
            cursor.execute("SELECT * FROM doctor")
            schedule = cursor.fetchall()
            return render_template('schedule.html',schedule=schedule,now=now)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/departments")
def departments():
    if "user" in session:
        if session["usertype"] == "admin":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            
            cursor.execute("SELECT * FROM department")
            department = cursor.fetchall()
            return render_template('departments.html',department=department)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/editdepartment/<int:departmentid>")
def editdepartment(departmentid):
    if "user" in session:
        if session["usertype"] == "admin":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

            row=cursor.execute("SELECT * FROM department where departmentid='%d'" %departmentid)
            row=cursor.fetchone()
            if row['status'] == "Active":
                cursor.execute("UPDATE department SET status='%s' WHERE departmentid='%s'" %("Inactive",(departmentid)))
            else:
                cursor.execute("UPDATE department SET status='%s' WHERE departmentid='%s'" %("Active",(departmentid)))
            mysql.connection.commit()
                
            return redirect('/departments')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")


# @app.route("/doctor_list")
# def doctor_list():
#     if "user" in session:
#         if session["usertype"] == "doctor":
#             return render_template('doctor_list.html')
#         else :
#             return redirect("/logout")
#     else :
#         return redirect("/login")



@app.route("/addappointment")
def addappointment():
    if "user" in session:
        if session["usertype"] == "patient":
            return render_template('add-appointment.html')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

# @app.route("/patient_appointment",methods = ['GET', 'POST'] )
# def patient_appointment():
#     if "user" in session:
#         if session["usertype"] == "patient":
#             msg=""
            
#             if request.method == 'POST':   
#                 cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)          
#                 name=request.form.get("name")
#                 department = request.form.get("department")
#                 doctor=request.form.get("doctor")
#                 date=request.form.get("date")
#                 time=request.form.get("time")
#                 email=request.form.get("email")

#                 phone=request.form.get("phoneno")
#                 messg=request.form.get("messg")
#                 cursor.execute("INSERT INTO appointment (patientname,departmentname,doctorname,appointmentdate,appointmenttime,phone,email,message) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" %(name,department,doctor,date,time,email,phone,messg))
#                 mysql.connection.commit()
#                 msg="Appointment is Scheduled"
#                 flash(msg)
#                 return redirect("/patient_appointment")
#             cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
#             cursor.execute("SELECT * FROM doctor")
#             doctor = cursor.fetchall()
#             cursor.execute("SELECT * FROM department")
#             department = cursor.fetchall()
            
#             return render_template('appointment.html', doctor=doctor,department=department)
#         else :
#             return redirect("/logout")
#     else :
#         return redirect("/login")


@app.route("/dataentrys")
def dataentrys():
    if "user" in session:
        if session["usertype"] == "admin":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            
            cursor.execute("SELECT * FROM login WHERE usertype='data_entry'")
            login = cursor.fetchall()
            
            return render_template('dataentrys.html',login=login)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")
    
@app.route("/admin_dataentry")
def admin_dataentry():
    if "user" in session:
        if session["usertype"] == "admin":
            return render_template('add-dataentry.html')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")
    
@app.route("/adddataentry", methods = ['GET', 'POST'])
def adddatentry():
    if "user" in session:
        if session["usertype"] == "admin":
            if request.method == 'POST':
                
                cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                userid=request.form.get("userid")
                #email=request.form.get("email")
                password=request.form.get("password")
                cnfpassword=request.form.get("cnfpassword")
                
                
                #password verification
                if not password==cnfpassword:
                    pmsg="Passwords did not match. Try again."
                    flash(pmsg)
                    return render_template('add-dataentry.html')

               
                
                #cursor.execute("INSERT INTO login (doctorid, doctorname,mobileno,departmentname, status,education,experience,consultancy_charge,gender) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" %(doctorid, name,phone,departmentname,status,education,experience,consultancycharge,gender))
                #mysql.connection.commit()
                cursor.execute("INSERT INTO login VALUES ('%s', '%s', 'data_entry')" %(userid, password))
                mysql.connection.commit()

                smsg="Data Entry Operator added successfully.\nUserID is "+userid+"."
                flash(smsg, 'success')
                return redirect("/admin_dataentry")
        else :
            return redirect("/logout")
    else :
        return redirect("/login")
    
@app.route("/deletedataentry/<userid>")
def deletedataentry(userid):
    if "user" in session:
        if session["usertype"] == "admin":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute("DELETE from login where userid='%s'" %(userid))
            mysql.connection.commit()
            return redirect('/dataentrys')
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/invoices")
def invoices():
    if "user" in session:
        if session["usertype"] == "admin":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute("SELECT * FROM billing")
            bills = cursor.fetchall()
            return render_template('invoices.html',bills=bills,)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/invoicesbill/<int:billingid>")
def invoicesbill(billingid):
    if "user" in session:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("SELECT * FROM  billing where billingid='%d'" %billingid)
        row=cursor.fetchone()
        cursor.execute("SELECT * FROM  appointment where patientname='%s'" %row['patientname'])
        patientname=cursor.fetchone()
        cursor.execute("SELECT * FROM  doctor where doctorname='%s'" %patientname['doctorname'])
        doctor=cursor.fetchone()
        medi = np.random.randint(10000,20000)
        print(doctor['consultancy_charge'])
        sub = float(doctor['consultancy_charge']) + medi + 5000 
        tax = np.random.randint(10,25)
        taxamt =math.trunc(sub * (tax/100))
        grand = taxamt + sub 
        return render_template("invoice-bill.html",row=row,doctor=doctor,medical = medi,grand = grand,taxamt = taxamt,tax=tax)
    else :
            return redirect("/login")

@app.route("/invoices_bill")
def invoices_bill():
    if "user" in session:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("SELECT * FROM  billing where patientname='%s'" %session['userid'])
        row=cursor.fetchone()
        cursor.execute("SELECT * FROM  appointment where patientname='%s'" %row['patientname'])
        patientname=cursor.fetchone()
        cursor.execute("SELECT * FROM  doctor where doctorname='%s'" %patientname['doctorname'])
        doctor=cursor.fetchone()
        medi = np.random.randint(10000,20000)
        print(doctor['consultancy_charge'])
        sub = float(doctor['consultancy_charge']) + medi + 5000 
        tax = np.random.randint(10,25)
        taxamt =math.trunc(sub * (tax/100))
        grand = taxamt + sub 
        return render_template("invoice-bill.html",row=row,doctor=doctor,medical = medi,grand = grand,taxamt = taxamt,tax=tax)
    else :
            return redirect("/login")
    
@app.route("/show_patients")
def show_patients():
    if "user" in session:
        if session["usertype"] == "doctor":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            doctorid=session["userid"]
            cursor.execute("SELECT status from doctor WHERE doctorid='%s'" %(doctorid))
            doctor=cursor.fetchall()
            cursor.execute("SELECT DISTINCT patient.patientid, patient.patientname,patient.age,patient.address,patient.city, patient.mobileno,patient.email,patient.illness FROM patient,appointment WHERE patient.patientid=appointment.patientid AND appointment.status='APPROVED' AND appointment.doctorid='%s'" %(doctorid))
            #cursor.execute("SELECT * FROM  patient")
            approved_patient = cursor.fetchall()
            cursor.execute("SELECT DISTINCT patient.patientid, patient.patientname,patient.age,patient.address,patient.city, patient.mobileno,patient.email,patient.illness FROM patient,appointment WHERE patient.patientid=appointment.patientid AND appointment.status='ONGOING' AND appointment.doctorid='%s'" %(doctorid))
            ongoing_patient=cursor.fetchall()
            cursor.execute("SELECT DISTINCT patient.patientid, patient.patientname,patient.age,patient.address,patient.city, patient.mobileno,patient.email,patient.illness FROM patient,appointment WHERE patient.patientid=appointment.patientid AND appointment.status='OBSERVATION' AND appointment.doctorid='%s'" %(doctorid))
            observation_patient=cursor.fetchall()
            #return render_template('patients.html',patient=patient)
            
            return render_template('show-patients.html',patient=approved_patient,patient1=ongoing_patient,patient2=observation_patient,doctor=doctor)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")
    
@app.route("/doctordash")
def doctordash():
    if "user" in session:
        if session["usertype"] == "doctor":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            doctorid=session["userid"]
            cursor.execute("SELECT * from doctor WHERE doctorid='%s'" %(doctorid))
            doctor=cursor.fetchall()
            cursor.execute("SELECT DISTINCT patient.patientid, patient.patientname,patient.age,patient.address,patient.city, patient.mobileno,patient.email,patient.illness FROM patient,appointment WHERE patient.patientid=appointment.patientid AND appointment.status='APPROVED' AND appointment.doctorid='%s'" %(doctorid))
            #cursor.execute("SELECT * FROM  patient")
            approved_patient = cursor.fetchall()
            cursor.execute("SELECT DISTINCT patient.patientid, patient.patientname,patient.age,patient.address,patient.city, patient.mobileno,patient.email,patient.illness FROM patient,appointment WHERE patient.patientid=appointment.patientid AND appointment.status='ONGOING' AND appointment.doctorid='%s'" %(doctorid))
            ongoing_patient=cursor.fetchall()
            #return render_template('patients.html',patient=patient)
            
            return render_template('doctordash.html',patient=approved_patient,patient1=ongoing_patient,doctor=doctor)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/data_entry")
def data_entry():
    if "user" in session:
        if session["usertype"] == "data_entry":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            # doctorid=session["userid"]
            
            # cursor.execute("SELECT patient.patientid, patient.patientname FROM patient,appointment WHERE patient.patientid=appointment.patientid AND appointment.doctorid='%s'" %(doctorid))
            cursor.execute("SELECT * FROM  appointment,patient,doctor WHERE appointment.patientid=patient.patientid AND appointment.doctorid=doctor.doctorid AND appointment.status='OBSERVATION'")   # where status= ongoing OR status is OBSERVATion
            observation_patient = cursor.fetchall()
            cursor.execute("SELECT * FROM  appointment,patient,doctor WHERE appointment.patientid=patient.patientid AND appointment.doctorid=doctor.doctorid AND appointment.status='ONGOING'")   # where status= ongoing OR status is ONGOING
            ongoing_patient = cursor.fetchall()
            return render_template('data-entry.html',ongoing_patient=ongoing_patient,observation_patient=observation_patient)
        else :
            return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/update_prescription", methods = ['GET', 'POST'])
def update_prescription():
    if "user" in session:
        if session["usertype"] == "data_entry":
            if request.method == 'POST':
                cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                treatment=request.form.get("data1")
                test=request.form.get("data2")
                status=request.form.get("status")
                myVariable=request.form.get("myVariable")
                appid=int(myVariable)
                # get the status
                cursor.execute("SELECT * FROM appointment WHERE appointmentid='%s'" %(myVariable))
                apptable = cursor.fetchone()
                patientid = apptable['patientid']
                #cursor.execute("SELECT doctorid FROM appointment WHERE appointmentid='%s'" %(myVariable))
                doctorid = apptable['doctorid']
                
                print("Treatment:")
                print(treatment)  
                print("Test:")
                print(test)
                print("appid:")
                print(myVariable)
                print(patientid)
                print(doctorid)
                print(status)
                cursor.execute("INSERT INTO prescription (doctorid, patientid, appointmentid, treatment, test) VALUES('%s', '%s','%d','%s','%s')" %(doctorid, patientid, appid, treatment, test))
                mysql.connection.commit()
                cursor.execute("UPDATE appointment SET status= '%s' WHERE appointmentid='%s'" %(status,appid)) 
                mysql.connection.commit()
                return redirect("/data_entry")
            else :
                return redirect("/logout")
    else :
        return redirect("/login")

@app.route("/health_info")
def health_info():
    if "user" in session:
        if session["usertype"] == "patient":
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

            cursor.execute(
                "SELECT * FROM patient left join stay ON patient.patientid=stay.patientid  WHERE patient.patientid='%s'" %session["userid"])
            patient = cursor.fetchall()
            cursor.execute(
                "SELECT * FROM prescription JOIN doctor ON prescription.doctorid=doctor.doctorid WHERE patientid='%s'" %session["userid"])
            prescription = cursor.fetchall()
            cursor.execute(
                "SELECT * FROM appointment WHERE patientid='%s' order by appointmentdate" %session["userid"])
            appointment = cursor.fetchall()
            return render_template('health_info.html', patient=patient, prescription=prescription, appointment=appointment)
        else:
            return redirect("/logout")
    else:
        return redirect("/login")


@app.route("/patient_appointment", methods=['GET', 'POST'])
def patient_appointment():
    if "user" in session:
        if session["usertype"] == "patient":
            msg = ""

            if request.method == 'POST':

                cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                # count = cursor.execute("SELECT count(*) from appointment")
                # count = cursor.fetchone()['COUNT(*)']#print(count)
                # name=request.form.get("name")
                # department = request.form.get("department")
                doctor = request.form.get("doctor")
                date = request.form.get("date")
                current_date = datetime.now()
                date_object = datetime.strptime(date, "%Y-%m-%d")
                if date_object < current_date - timedelta(days=1):
                    msg = "Invalid date"
                    flash(msg)
                    return redirect("/patient_appointment")
                # time=request.form.get("time")
                # email=request.form.get("email")

                # cnt = count + 1

                # phone=request.form.get("phoneno")
                messg = request.form.get("messg")
                cursor.execute("INSERT INTO appointment (patientid, doctorid, appointmentdate) VALUES ('%s', '%s', '%s')" % (
                    session["userid"], doctor, date,))
                mysql.connection.commit()
                # del count
                # del cnt
                msg = "Appointment request is Submitted"
                flash(msg)
                return redirect("/patient_appointment")
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute("SELECT * FROM doctor WHERE status='ACTIVE'")
            doctor = cursor.fetchall()

            return render_template('appointment.html', doctor=doctor)
        else:
            return redirect("/logout")
    else:
        return redirect("/login")


app.run(host='127.0.0.1',port='9000',debug="True")
#app.run(debug=True)
